#!/bin/bash
#SBATCH --mail-user=pvnatu@wpi.edu
#SBATCH --mail-type=ALL



SBATCH -N 1
SBATCH -n 2
SBATCH --mem 500
SBATCH --gres=gpu:4
SBATCH --gpus-per-node=1
SBATCH -o Train.out
SBATCH --time=9:00:00

srun -l train_unsup.py